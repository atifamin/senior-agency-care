</div>
</div>


<!-- Core JS files -->
	<!-- Core JS files -->
	<script src="<?php echo base_url(); ?>/assets/js/main/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/main/bootstrap.bundle.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/plugins/loaders/blockui.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/plugins/ui/ripple.min.js"></script>
	<!-- /core JS files -->

	<!-- Theme JS files -->
	<script src="<?php echo base_url(); ?>/assets/js/plugins/forms/wizards/steps.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/plugins/forms/selects/select2.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/plugins/forms/styling/uniform.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/plugins/forms/inputs/inputmask.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/plugins/forms/validation/validate.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/plugins/extensions/cookie.js"></script>

	<script src="<?php echo base_url(); ?>/assets/js/app.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/demo_pages/form_wizard.js"></script>
	<!-- /theme JS files -->
	<!-- /core JS files -->

	<!-- Theme JS files -->
	<script src="<?php echo base_url(); ?>/assets/js/plugins/extensions/jquery_ui/interactions.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/demo_pages/form_select2.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/forms/selects/bootstrap_multiselect.js"></script>
<script src="<?php echo base_url();?>assets/js/demo_pages/form_multiselect.js"></script>
<script src="<?php echo base_url();?>assets/js/demo_pages/extra_sweetalert.js"></script>
</body>
</html>