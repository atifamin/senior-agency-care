<div class="row" id="client_bio_area">
  <?php include(APPPATH."views/agency/scheduling/inc/client_bio/view.php"); ?>
</div>
