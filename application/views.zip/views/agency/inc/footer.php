</div>
</div>
<?php include(APPPATH."views/plugins/ImageCropper/image_cropper_modal.php"); ?>
</body>
</html>