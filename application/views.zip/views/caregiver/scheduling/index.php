<?php include(APPPATH."views/caregiver/inc/header.php"); ?>
<div class="row" style="width: 100%; margin-left: 1px;">
  <div class="col-md-12" style="padding: 0;"> 
  	<div class="card card-body">
  		<!-- List view -->
    	<div class="fullcalendar-list"></div>
    	<!-- /list view -->
  	</div> 
  </div>
</div>


<script src="<?php echo base_url(); ?>assets/js/plugins/ui/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/ui/fullcalendar/fullcalendar.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/demo_pages/fullcalendar_basic.js"></script>


<?php include(APPPATH."views/caregiver/inc/footer.php"); ?>